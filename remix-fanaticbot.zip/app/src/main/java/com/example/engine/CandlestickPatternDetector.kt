package com.example.engine

import com.example.model.Candle
import com.example.model.CandlePatternType
import com.example.model.DetectedCandlePattern

object CandlestickPatternDetector {

  fun analyzePatterns(candles: List<Candle>): List<DetectedCandlePattern> {
    if (candles.size < 3) return emptyList()
    val results = mutableListOf<DetectedCandlePattern>()

    for (i in 1 until candles.size) {
      val curr = candles[i]
      val prev = candles[i - 1]

      // 1. Bullish Engulfing
      if (!prev.isBullish && curr.isBullish &&
          curr.close >= prev.open && curr.open <= prev.close &&
          curr.bodyRange >= prev.bodyRange * 1.05) {
        results.add(
          DetectedCandlePattern(
            pattern = CandlePatternType.BULLISH_ENGULFING,
            candleIndex = i,
            price = curr.close,
            isBullish = true,
            description = "Bullish Engulfing: Demand engulfed prior selling candle body"
          )
        )
        continue
      }

      // 2. Bearish Engulfing
      if (prev.isBullish && !curr.isBullish &&
          curr.close <= prev.open && curr.open >= prev.close &&
          curr.bodyRange >= prev.bodyRange * 1.05) {
        results.add(
          DetectedCandlePattern(
            pattern = CandlePatternType.BEARISH_ENGULFING,
            candleIndex = i,
            price = curr.close,
            isBullish = false,
            description = "Bearish Engulfing: Supply engulfed prior buying candle body"
          )
        )
        continue
      }

      // 3. Bullish Rejection Pin Bar / Hammer (lower wick >= 1.8 * body, upper wick small)
      if (curr.lowerWick >= (curr.bodyRange * 1.6).coerceAtLeast(0.0001) && curr.upperWick <= curr.bodyRange * 1.2) {
        results.add(
          DetectedCandlePattern(
            pattern = CandlePatternType.BULLISH_PIN_BAR,
            candleIndex = i,
            price = curr.low,
            isBullish = true,
            description = "Rejection Pin Bar: Aggressive liquidity sweep rejection from lows"
          )
        )
        continue
      }

      // 4. Bearish Shooting Star / Upper Pin Bar (upper wick >= 1.8 * body, lower wick small)
      if (curr.upperWick >= (curr.bodyRange * 1.6).coerceAtLeast(0.0001) && curr.lowerWick <= curr.bodyRange * 1.2) {
        results.add(
          DetectedCandlePattern(
            pattern = CandlePatternType.BEARISH_PIN_BAR,
            candleIndex = i,
            price = curr.high,
            isBullish = false,
            description = "Shooting Star: Aggressive liquidity sweep rejection from highs"
          )
        )
        continue
      }

      // 5. Morning Star & Evening Star (3-Candle Reversals)
      if (i >= 2) {
        val c1 = candles[i - 2]
        val c2 = candles[i - 1]
        val c3 = curr

        // Morning Star
        if (!c1.isBullish && c2.bodyRange <= c1.bodyRange * 0.45 && c3.isBullish && c3.close > (c1.open + c1.close) / 2.0) {
          results.add(
            DetectedCandlePattern(
              pattern = CandlePatternType.MORNING_STAR,
              candleIndex = i,
              price = c3.close,
              isBullish = true,
              description = "Morning Star: 3-candle institutional reversal at Demand"
            )
          )
          continue
        }

        // Evening Star
        if (c1.isBullish && c2.bodyRange <= c1.bodyRange * 0.45 && !c3.isBullish && c3.close < (c1.open + c1.close) / 2.0) {
          results.add(
            DetectedCandlePattern(
              pattern = CandlePatternType.EVENING_STAR,
              candleIndex = i,
              price = c3.close,
              isBullish = false,
              description = "Evening Star: 3-candle institutional reversal at Supply"
            )
          )
          continue
        }
      }

      // 6. Bullish / Bearish Expansion Momentum
      if (curr.bodyRange >= curr.totalRange * 0.65 && curr.bodyRange >= prev.bodyRange * 1.4) {
        val isBull = curr.isBullish
        results.add(
          DetectedCandlePattern(
            pattern = if (isBull) CandlePatternType.BULLISH_MOMENTUM else CandlePatternType.BEARISH_MOMENTUM,
            candleIndex = i,
            price = curr.close,
            isBullish = isBull,
            description = if (isBull) "Bullish Expansion: Strong institutional displacement candle" else "Bearish Expansion: Strong institutional displacement candle"
          )
        )
      }
    }

    return results
  }
}
