package com.example.engine

import com.example.data.BotSettingsEntity
import com.example.data.TradeEntity
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs
import kotlin.random.Random

class TradingBotEngine {

  private val _selectedPair = MutableStateFlow("EURUSD")
  val selectedPair: StateFlow<String> = _selectedPair.asStateFlow()

  private val _selectedTimeframe = MutableStateFlow(Timeframe.MTF_15M)
  val selectedTimeframe: StateFlow<Timeframe> = _selectedTimeframe.asStateFlow()

  private val _candles = MutableStateFlow<List<Candle>>(emptyList())
  val candles: StateFlow<List<Candle>> = _candles.asStateFlow()

  private val _marketTrend = MutableStateFlow(MarketTrend.UPTREND)
  val marketTrend: StateFlow<MarketTrend> = _marketTrend.asStateFlow()

  private val _pdRange = MutableStateFlow(PDRange(1.08950, 1.08150))
  val pdRange: StateFlow<PDRange> = _pdRange.asStateFlow()

  private val _orderBlocks = MutableStateFlow<List<OrderBlock>>(emptyList())
  val orderBlocks: StateFlow<List<OrderBlock>> = _orderBlocks.asStateFlow()

  private val _fairValueGaps = MutableStateFlow<List<FairValueGap>>(emptyList())
  val fairValueGaps: StateFlow<List<FairValueGap>> = _fairValueGaps.asStateFlow()

  private val _swingPoints = MutableStateFlow<List<SwingPoint>>(emptyList())
  val swingPoints: StateFlow<List<SwingPoint>> = _swingPoints.asStateFlow()

  private val _structureLines = MutableStateFlow<List<StructureLine>>(emptyList())
  val structureLines: StateFlow<List<StructureLine>> = _structureLines.asStateFlow()

  private val _asianRangeBox = MutableStateFlow<AsianRangeBox?>(null)
  val asianRangeBox: StateFlow<AsianRangeBox?> = _asianRangeBox.asStateFlow()

  private val _fibonacciRetracement = MutableStateFlow<FibonacciRetracement?>(null)
  val fibonacciRetracement: StateFlow<FibonacciRetracement?> = _fibonacciRetracement.asStateFlow()

  private val _detectedCandlePatterns = MutableStateFlow<List<DetectedCandlePattern>>(emptyList())
  val detectedCandlePatterns: StateFlow<List<DetectedCandlePattern>> = _detectedCandlePatterns.asStateFlow()

  private val _liquidityEvents = MutableStateFlow<List<LiquidityEvent>>(emptyList())
  val liquidityEvents: StateFlow<List<LiquidityEvent>> = _liquidityEvents.asStateFlow()

  private val _currentSignal = MutableStateFlow<TradingSignal?>(null)
  val currentSignal: StateFlow<TradingSignal?> = _currentSignal.asStateFlow()

  private val _activePositions = MutableStateFlow<List<ActivePosition>>(emptyList())
  val activePositions: StateFlow<List<ActivePosition>> = _activePositions.asStateFlow()

  private val _currentWindow = MutableStateFlow(getCurrentTradeWindow())
  val currentWindow: StateFlow<TradeWindowSession> = _currentWindow.asStateFlow()

  private val _dailyLossStreak = MutableStateFlow(0)
  val dailyLossStreak: StateFlow<Int> = _dailyLossStreak.asStateFlow()

  private val _dailyLossPercent = MutableStateFlow(0.0)
  val dailyLossPercent: StateFlow<Double> = _dailyLossPercent.asStateFlow()

  private val _weeklyLossPercent = MutableStateFlow(0.0)
  val weeklyLossPercent: StateFlow<Double> = _weeklyLossPercent.asStateFlow()

  private val _circuitBreakerHaltReason = MutableStateFlow<String?>(null)
  val circuitBreakerHaltReason: StateFlow<String?> = _circuitBreakerHaltReason.asStateFlow()

  private val _upcomingNews = MutableStateFlow<List<EconomicNewsEvent>>(createDefaultEconomicCalendar())
  val upcomingNews: StateFlow<List<EconomicNewsEvent>> = _upcomingNews.asStateFlow()

  private val _activeNewsBlackout = MutableStateFlow<EconomicNewsEvent?>(null)
  val activeNewsBlackout: StateFlow<EconomicNewsEvent?> = _activeNewsBlackout.asStateFlow()

  init {
    loadPairData("EURUSD", Timeframe.MTF_15M)
  }

  fun selectPair(pair: String) {
    _selectedPair.value = pair
    loadPairData(pair, _selectedTimeframe.value)
  }

  fun selectTimeframe(tf: Timeframe) {
    _selectedTimeframe.value = tf
    loadPairData(_selectedPair.value, tf)
  }

  fun refreshWindow() {
    _currentWindow.value = getCurrentTradeWindow()
  }

  fun calculateLotSize(balance: Double, riskPercent: Double, entryPrice: Double, stopLossPrice: Double, pair: String): Double {
    val riskDollars = balance * (riskPercent / 100.0)
    val pipDifference = abs(entryPrice - stopLossPrice)
    val pipValuePerLot = when (pair) {
      "US30" -> 1.0 // 1 point = $1 per lot
      else -> 10.0  // Standard FX lot: 1 pip (0.0001) = $10
    }
    val pips = if (pair == "US30") pipDifference else pipDifference * 10000.0
    if (pips <= 0.0) return 0.1
    val calculatedLots = riskDollars / (pips * pipValuePerLot)
    return (Math.round(calculatedLots * 100.0) / 100.0).coerceIn(0.01, 50.0)
  }

  fun evaluateCircuitBreakers(settings: BotSettingsEntity, todayTrades: List<TradeEntity>) {
    var dayLoss = 0.0
    var consecutiveLosses = 0
    var tempStreak = 0

    val todayClosed = todayTrades.filter { it.status == "CLOSED" }
    for (trade in todayClosed.sortedBy { it.timestamp }) {
      if (trade.pnl < 0) {
        dayLoss += abs(trade.pnl)
        tempStreak++
        consecutiveLosses = maxOf(consecutiveLosses, tempStreak)
      } else {
        tempStreak = 0
      }
    }

    val dayLossPct = if (settings.balance > 0) (dayLoss / settings.balance) * 100.0 else 0.0
    _dailyLossPercent.value = dayLossPct
    _dailyLossStreak.value = consecutiveLosses

    val window = getCurrentTradeWindow()
    _currentWindow.value = window

    val now = System.currentTimeMillis()
    val activeBlackout = _upcomingNews.value.firstOrNull {
      it.impact == NewsImpact.HIGH_RED_FOLDER && it.isInBlackoutWindow(now)
    }
    _activeNewsBlackout.value = activeBlackout

    when {
      activeBlackout != null -> {
        val mins = activeBlackout.minutesUntil(now)
        val timingDesc = if (mins >= 0) "${mins}m until release" else "${abs(mins)}m since release"
        _circuitBreakerHaltReason.value = "NEWS SHIELD ACTIVE: High-Impact Red Folder '${activeBlackout.title}' (${activeBlackout.currency}) in progress ($timingDesc). Strictly NO trading ±30 minutes around news!"
      }
      dayLossPct >= settings.maxDailyLossPercent -> {
        _circuitBreakerHaltReason.value = "DAILY LOSS LIMIT HIT (${String.format("%.2f", dayLossPct)}% >= ${settings.maxDailyLossPercent}%). Hard Stop Trading for Today!"
      }
      consecutiveLosses >= settings.maxDailyLossStrikes -> {
        _circuitBreakerHaltReason.value = "MAX CONSECUTIVE LOSSES REACHED ($consecutiveLosses strikes >= ${settings.maxDailyLossStrikes}). Stop for Today!"
      }
      _weeklyLossPercent.value >= settings.maxWeeklyLossPercent -> {
        _circuitBreakerHaltReason.value = "WEEKLY LOSS LIMIT HIT (${String.format("%.2f", _weeklyLossPercent.value)}% >= ${settings.maxWeeklyLossPercent}%). Stop for this Week!"
      }
      !window.isTradeAllowed -> {
        _circuitBreakerHaltReason.value = "OUTSIDE TRADE WINDOW (${window.title}). ${window.advice}"
      }
      else -> {
        _circuitBreakerHaltReason.value = null
      }
    }
  }

  fun generateNewSignal(settings: BotSettingsEntity): TradingSignal {
    val pair = _selectedPair.value
    val currentCandles = _candles.value
    val lastCandle = currentCandles.lastOrNull()
    val basePrice = lastCandle?.close ?: if (pair == "US30") 39200.0 else 1.08500

    val isBullishBias = _marketTrend.value == MarketTrend.UPTREND
    val direction = if (isBullishBias) TradeDirection.BUY else TradeDirection.SELL

    val pipUnit = if (pair == "US30") 1.0 else 0.0001
    val slPips = Random.nextInt(4, 7).toDouble() // 4 to 6 pips
    val targetR = if (slPips < 5.0) 5.0 else 4.0 // Book rule: 5R if SL < 5 pips, 4R if SL > 5 pips

    val entryPrice = basePrice
    val stopLoss = if (direction == TradeDirection.BUY) entryPrice - (slPips * pipUnit) else entryPrice + (slPips * pipUnit)
    val takeProfit = if (direction == TradeDirection.BUY) entryPrice + (slPips * targetR * pipUnit) else entryPrice - (slPips * targetR * pipUnit)

    val currentWindow = getCurrentTradeWindow()
    val fib = _fibonacciRetracement.value
    val isDiscountOk = if (direction == TradeDirection.BUY) _pdRange.value.isDiscount(entryPrice) else _pdRange.value.isPremium(entryPrice)
    val isInOteZone = fib?.isInOteZone(entryPrice) == true
    val hasValidOB = _orderBlocks.value.any { it.isEngulfed && it.hasMomentum }
    val hasSweep = _liquidityEvents.value.any { it.type == LiquidityType.LIQUIDITY_GRAB }
    val isLossLimitOk = _circuitBreakerHaltReason.value == null
    val now = System.currentTimeMillis()
    val activeBlackout = _upcomingNews.value.firstOrNull {
      it.impact == NewsImpact.HIGH_RED_FOLDER && it.isInBlackoutWindow(now)
    }
    val isNewsClear = activeBlackout == null

    val recentPatterns = _detectedCandlePatterns.value
    val candleConfirmation = recentPatterns.lastOrNull { it.isBullish == isBullishBias }
    val hasCandlePattern = candleConfirmation != null

    val checklist = listOf(
      RuleCheckResult(
        "Candlestick Pattern Confirmation",
        hasCandlePattern,
        if (hasCandlePattern) "Confirmed: ${candleConfirmation?.pattern?.label} (${candleConfirmation?.pattern?.icon}) at Key Zone" else "Waiting: No institutional confirmation candle (Engulfing / Pin Bar) detected"
      ),
      RuleCheckResult(
        "News Shield (±30 Min Lock)",
        isNewsClear,
        if (isNewsClear) "Clear: No High-Impact Red Folder news within ±30 minutes" else "LOCKED: Red Folder '${activeBlackout?.title}' (${activeBlackout?.currency}) active within ±30m window!"
      ),
      RuleCheckResult(
        "HTF 4H Trend Alignment",
        isBullishBias,
        if (isBullishBias) "4H Bullish (HH/HL held, trading from Strong Low)" else "4H Bearish (LH/LL held, trading from Strong High)"
      ),
      RuleCheckResult(
        "Fibonacci OTE (61.8% - 78.6%)",
        isDiscountOk,
        if (isInOteZone) "Institutional OTE Sweet Spot (70.5% Retracement inside Discount)" else if (isDiscountOk) "In Discount Zone (< 50% Equilibrium)" else "Failed: In Premium (> 50% EQ)"
      ),
      RuleCheckResult(
        "15M Order Block (OB) Validation",
        hasValidOB,
        "Order block engulfed by next candle, caused impulsive Structure Break (SB)"
      ),
      RuleCheckResult(
        "Liquidity Grab (LG) / Sweep",
        hasSweep,
        "Early retail stops & liquidity taken out below Asian/session low before true move"
      ),
      RuleCheckResult(
        "1M Trend Change (TC) Alignment",
        true,
        "1M broke last minor structure with momentum and aligned with 15M/4H direction"
      ),
      RuleCheckResult(
        "Trade Window Session",
        currentWindow.isTradeAllowed,
        "${currentWindow.title} (${currentWindow.gmtTimeRange}) - ${if (currentWindow.isTradeAllowed) "Trade Allowed" else "Restricted"}"
      ),
      RuleCheckResult(
        "Risk Guardian Rule (0.25% - 1.0%)",
        isLossLimitOk,
        "Effective risk locked to ${String.format("%.2f", settings.effectiveRiskPercent)}%. Daily/Weekly loss limits respected."
      )
    )

    val isExecutable = checklist.all { it.isPassed }
    val signal = TradingSignal(
      id = "SIG_${System.currentTimeMillis()}",
      timestamp = System.currentTimeMillis(),
      symbol = pair,
      direction = direction,
      strategy = StrategyModel.PRECISION,
      entryPrice = entryPrice,
      stopLoss = stopLoss,
      takeProfit = takeProfit,
      targetR = targetR,
      pipsRisk = slPips,
      reasonChecklist = checklist,
      isExecutable = isExecutable
    )

    _currentSignal.value = signal
    return signal
  }

  fun executeSignal(signal: TradingSignal, settings: BotSettingsEntity): ActivePosition {
    val lotSize = calculateLotSize(settings.balance, settings.effectiveRiskPercent, signal.entryPrice, signal.stopLoss, signal.symbol)
    val riskAmount = settings.balance * (settings.effectiveRiskPercent / 100.0)

    val pos = ActivePosition(
      id = System.currentTimeMillis(),
      symbol = signal.symbol,
      direction = signal.direction,
      strategy = signal.strategy,
      entryPrice = signal.entryPrice,
      currentPrice = signal.entryPrice,
      stopLoss = signal.stopLoss,
      takeProfit = signal.takeProfit,
      lotSize = lotSize,
      riskAmount = riskAmount,
      openTimestamp = System.currentTimeMillis(),
      pnl = 0.0,
      currentR = 0.0,
      isPartialsTaken = false,
      isBreakeven = false
    )

    val updated = _activePositions.value.toMutableList()
    updated.add(pos)
    _activePositions.value = updated
    _currentSignal.value = null
    return pos
  }

  fun takePartials(posId: Long): ActivePosition? {
    val list = _activePositions.value.toMutableList()
    val index = list.indexOfFirst { it.id == posId }
    if (index >= 0) {
      val pos = list[index]
      val securedPnl = pos.riskAmount * 3.5 // Take partials at 3.5R
      pos.isPartialsTaken = true
      pos.pnl += securedPnl
      list[index] = pos
      _activePositions.value = list
      return pos
    }
    return null
  }

  fun moveBreakeven(posId: Long): ActivePosition? {
    val list = _activePositions.value.toMutableList()
    val index = list.indexOfFirst { it.id == posId }
    if (index >= 0) {
      val pos = list[index]
      pos.isBreakeven = true
      list[index] = pos
      _activePositions.value = list
      return pos
    }
    return null
  }

  fun closePosition(posId: Long, exitPrice: Double? = null, reason: String = "Manual Close"): TradeEntity? {
    val list = _activePositions.value.toMutableList()
    val index = list.indexOfFirst { it.id == posId }
    if (index >= 0) {
      val pos = list[index]
      val elapsedMillis = System.currentTimeMillis() - pos.openTimestamp
      val minHoldMillis = 3 * 60 * 1000L // 3 minutes minimum hold rule

      if (elapsedMillis < minHoldMillis) {
        // Enforce 3-minute minimum hold rule strictly
        return null
      }

      list.removeAt(index)
      _activePositions.value = list
      val closePrice = exitPrice ?: pos.currentPrice
      val r = pos.currentR
      val pnl = pos.pnl

      return TradeEntity(
        timestamp = System.currentTimeMillis(),
        symbol = pos.symbol,
        direction = pos.direction.name,
        strategy = pos.strategy.name,
        entryPrice = pos.entryPrice,
        stopLoss = pos.stopLoss,
        takeProfit = pos.takeProfit,
        exitPrice = closePrice,
        lotSize = pos.lotSize,
        riskPercent = 0.25,
        pnl = pnl,
        rMultiple = r,
        status = "CLOSED",
        isRuleCompliant = true,
        emotionTag = "Disciplined",
        exitReason = reason,
        notes = "Closed according to trade plan rules (held > 3 minutes)."
      )
    }
    return null
  }

  fun tickLiveMarket(settings: BotSettingsEntity, onTradeClosed: (TradeEntity) -> Unit) {
    val pair = _selectedPair.value
    val candleList = _candles.value.toMutableList()
    if (candleList.isEmpty()) return

    val last = candleList.last()
    val step = if (pair == "US30") Random.nextDouble(1.0, 15.0) else Random.nextDouble(0.00002, 0.00015)
    val delta = if (Random.nextBoolean()) step else -step
    val newClose = (last.close + delta).coerceAtLeast(0.001)
    val newHigh = maxOf(last.high, newClose)
    val newLow = minOf(last.low, newClose)
    candleList[candleList.lastIndex] = last.copy(close = newClose, high = newHigh, low = newLow)
    _candles.value = candleList

    // Update active positions
    val openPositions = _activePositions.value.toMutableList()
    val closedTrades = mutableListOf<TradeEntity>()
    val remainingPositions = mutableListOf<ActivePosition>()

    for (pos in openPositions) {
      pos.currentPrice = newClose
      val slDist = abs(pos.entryPrice - pos.stopLoss).coerceAtLeast(0.00001)
      val currentDist = if (pos.direction == TradeDirection.BUY) newClose - pos.entryPrice else pos.entryPrice - newClose
      pos.currentR = Math.round((currentDist / slDist) * 10.0) / 10.0
      pos.pnl = pos.riskAmount * pos.currentR

      // Check Take Profit (5R)
      val isTpHit = if (pos.direction == TradeDirection.BUY) newClose >= pos.takeProfit else newClose <= pos.takeProfit
      val isSlHit = if (pos.direction == TradeDirection.BUY) newClose <= (if (pos.isBreakeven) pos.entryPrice else pos.stopLoss) else newClose >= (if (pos.isBreakeven) pos.entryPrice else pos.stopLoss)

      // Auto partials at 3R if enabled
      if (settings.autoPartialsAt3R && !pos.isPartialsTaken && pos.currentR >= 3.0) {
        pos.isPartialsTaken = true
        pos.isBreakeven = true // move to BE on partials!
      }

      // Auto breakeven if enabled
      if (settings.autoCloseAtBreakeven && !pos.isBreakeven && pos.currentR >= 2.0) {
        pos.isBreakeven = true
      }

      // Natural TP and SL hit (Broker executes hard TP / SL orders immediately)
      if (isTpHit) {
        closedTrades.add(
          TradeEntity(
            timestamp = System.currentTimeMillis(),
            symbol = pos.symbol,
            direction = pos.direction.name,
            strategy = pos.strategy.name,
            entryPrice = pos.entryPrice,
            stopLoss = pos.stopLoss,
            takeProfit = pos.takeProfit,
            exitPrice = newClose,
            lotSize = pos.lotSize,
            riskPercent = settings.effectiveRiskPercent,
            pnl = pos.riskAmount * 5.0,
            rMultiple = 5.0,
            status = "CLOSED",
            isRuleCompliant = true,
            emotionTag = "Disciplined",
            exitReason = "Take Profit Hit (5R Target reached)",
            notes = "Target reached at Weak High/Low. Executed by hard broker TP."
          )
        )
      } else if (isSlHit) {
        val finalR = if (pos.isBreakeven) 0.0 else -1.0
        val finalPnl = if (pos.isBreakeven) 0.0 else -pos.riskAmount
        closedTrades.add(
          TradeEntity(
            timestamp = System.currentTimeMillis(),
            symbol = pos.symbol,
            direction = pos.direction.name,
            strategy = pos.strategy.name,
            entryPrice = pos.entryPrice,
            stopLoss = pos.stopLoss,
            takeProfit = pos.takeProfit,
            exitPrice = newClose,
            lotSize = pos.lotSize,
            riskPercent = settings.effectiveRiskPercent,
            pnl = finalPnl,
            rMultiple = finalR,
            status = "CLOSED",
            isRuleCompliant = true,
            emotionTag = "Calm",
            exitReason = if (pos.isBreakeven) "Breakeven Hit (0R loss)" else "Stop Loss Hit (-1.0R risk protected)",
            notes = "Hard broker SL executed. Capital safe and intact."
          )
        )
      } else {
        remainingPositions.add(pos)
      }
    }

    _activePositions.value = remainingPositions
    closedTrades.forEach { onTradeClosed(it) }
  }

  private fun loadPairData(pair: String, tf: Timeframe) {
    val basePrice = when (pair) {
      "US30" -> 39250.0
      "GBPUSD" -> 1.28500
      else -> 1.08500
    }
    val pipUnit = if (pair == "US30") 5.0 else 0.0003

    // Synthesize realistic price action reflecting the book's SMC principles:
    // (Accumulation/Asian range -> Manipulation/LG Sweep -> Impulsive Breakout/Structure Break -> Retest of 50% OB)
    val now = System.currentTimeMillis()
    val candleInterval = when (tf) {
      Timeframe.HTF_4H -> 14400000L
      Timeframe.MTF_15M -> 900000L
      Timeframe.LTF_1M -> 60000L
    }

    val list = mutableListOf<Candle>()
    var current = basePrice

    // Generate 32 candles with an SMC structure pattern
    for (i in 30 downTo 0) {
      val t = now - (i * candleInterval)
      val cycleProgress = (30 - i)
      val bias = when {
        cycleProgress < 8 -> 0.0 // Asian range flat
        cycleProgress in 8..11 -> -1.5 // Manipulation / Liquidity sweep down
        cycleProgress in 12..20 -> 2.5 // Impulsive upward move / SB / TC
        cycleProgress in 21..26 -> -0.8 // Retracement into 50% discount demand zone
        else -> 1.8 // Expansion towards weak high
      }

      val change = (bias * pipUnit) + (Random.nextDouble(-0.4, 0.4) * pipUnit)
      val open = current
      val close = open + change
      val high = maxOf(open, close) + (Random.nextDouble(0.1, 0.5) * pipUnit)
      val low = minOf(open, close) - (Random.nextDouble(0.1, 0.5) * pipUnit)
      current = close

      list.add(Candle(t, open, high, low, close))
    }

    _candles.value = list
    _marketTrend.value = MarketTrend.UPTREND

    val lowestPrice = list.minOf { it.low }
    val highestPrice = list.maxOf { it.high }
    _pdRange.value = PDRange(highestPrice, lowestPrice)

    // Calculate full Fibonacci Retracement across current swing range
    _fibonacciRetracement.value = FibonacciRetracement(
      highPrice = highestPrice,
      lowPrice = lowestPrice,
      isBullish = true
    )

    // 1. Calculate Fair Value Gaps (FVG / Imbalances) across 3-candle windows
    val fvgs = mutableListOf<FairValueGap>()
    for (i in 2 until list.size) {
      val c1 = list[i - 2]
      val c2 = list[i - 1]
      val c3 = list[i]

      // Bullish FVG (+FVG): Large bullish c2 creates a gap where c3.low > c1.high
      if (c2.isBullish && c3.low > c1.high && (c3.low - c1.high) > (0.15 * pipUnit)) {
        fvgs.add(
          FairValueGap(
            id = "FVG_BULL_$i",
            isBullish = true,
            topPrice = c3.low,
            bottomPrice = c1.high,
            startIndex = i - 2,
            endIndex = minOf(list.size - 1, i + 8)
          )
        )
      }
      // Bearish FVG (-FVG): Large bearish c2 creates a gap where c3.high < c1.low
      else if (!c2.isBullish && c3.high < c1.low && (c1.low - c3.high) > (0.15 * pipUnit)) {
        fvgs.add(
          FairValueGap(
            id = "FVG_BEAR_$i",
            isBullish = false,
            topPrice = c1.low,
            bottomPrice = c3.high,
            startIndex = i - 2,
            endIndex = minOf(list.size - 1, i + 8)
          )
        )
      }
    }
    _fairValueGaps.value = fvgs

    // 2. Identify Order Blocks (Demand OB and Supply OB)
    val obCandle = list.getOrNull(10) ?: list.first()
    val highSupplyCandle = list.maxByOrNull { it.high } ?: list.last()
    _orderBlocks.value = listOf(
      OrderBlock(
        id = "OB_${tf.label}_DEMAND",
        type = OrderBlockType.BULLISH_DEMAND,
        topPrice = obCandle.bodyTop,
        bottomPrice = obCandle.low,
        timeframe = tf,
        isEngulfed = true,
        hasMomentum = true,
        isMitigated = false,
        formation = FormationType.SB
      ),
      OrderBlock(
        id = "OB_${tf.label}_SUPPLY",
        type = OrderBlockType.BEARISH_SUPPLY,
        topPrice = highSupplyCandle.high,
        bottomPrice = highSupplyCandle.bodyBottom,
        timeframe = tf,
        isEngulfed = true,
        hasMomentum = true,
        isMitigated = false,
        formation = FormationType.SB
      )
    )

    // 3. Mark Swing Points & Strong vs Weak Highs/Lows
    val lowestIndex = list.indexOfFirst { it.low == lowestPrice }.coerceAtLeast(0)
    val highestIndex = list.indexOfFirst { it.high == highestPrice }.coerceAtLeast(0)

    val swings = mutableListOf<SwingPoint>()
    // Lowest point after Asian sweep is the Strong Low (Protected by BFI because it caused new HH)
    swings.add(
      SwingPoint(
        index = lowestIndex,
        price = lowestPrice,
        isHigh = false,
        label = "Strong Low",
        isStrong = true
      )
    )
    // Target high is the Weak High (Failed to hold structure / Liquidity pool)
    swings.add(
      SwingPoint(
        index = highestIndex,
        price = highestPrice,
        isHigh = true,
        label = "Weak High",
        isWeak = true
      )
    )
    // Intermediate structure points (HH, HL)
    if (list.size > 20) {
      swings.add(SwingPoint(index = 18, price = list[18].high, isHigh = true, label = "HH"))
      swings.add(SwingPoint(index = 24, price = list[24].low, isHigh = false, label = "HL"))
    }
    _swingPoints.value = swings

    // 4. Structure Breaks (SB / BOS) and Trend Changes (TC / CHoCH)
    val previousHighLevel = list.take(12).maxOf { it.high }
    _structureLines.value = listOf(
      StructureLine(
        id = "SB_1",
        type = FormationType.SB,
        price = previousHighLevel,
        startIndex = 10,
        endIndex = 25,
        isBullish = true,
        label = "SB (Structure Break)"
      ),
      StructureLine(
        id = "TC_1",
        type = FormationType.TC,
        price = obCandle.high,
        startIndex = 8,
        endIndex = 18,
        isBullish = true,
        label = "TC (Trend Change / CHoCH)"
      )
    )

    // 5. Asian Range Box (01:00 - 05:00 GMT Accumulation)
    val asianCandles = list.take(8)
    if (asianCandles.isNotEmpty()) {
      _asianRangeBox.value = AsianRangeBox(
        high = asianCandles.maxOf { it.high },
        low = asianCandles.minOf { it.low },
        startIndex = 0,
        endIndex = 7,
        isSweptLow = true,
        isSweptHigh = false
      )
    }

    // 6. Liquidity Events (Sweeps & Pools)
    _liquidityEvents.value = listOf(
      LiquidityEvent(
        type = LiquidityType.LIQUIDITY_GRAB,
        price = obCandle.low,
        description = "Liquidity Grab (Sweep of Asian Low / Retail Stops)",
        timestamp = obCandle.time
      ),
      LiquidityEvent(
        type = LiquidityType.EQH,
        price = highestPrice,
        description = "Equal Highs (EQH) Liquidity Pool - Target Weak High",
        timestamp = list.last().time
      )
    )

    // 7. Candlestick Pattern Recognition Engine (Engulfing, Pin Bars, Stars)
    _detectedCandlePatterns.value = CandlestickPatternDetector.analyzePatterns(list)
  }

  companion object {
    fun getCurrentTradeWindow(): TradeWindowSession {
      val gmtCal = Calendar.getInstance(TimeZone.getTimeZone("GMT"))
      val hour = gmtCal.get(Calendar.HOUR_OF_DAY)
      return when (hour) {
        in 1..4 -> TradeWindowSession.ASIAN_RANGE
        6 -> TradeWindowSession.PRE_LONDON
        in 7..10 -> TradeWindowSession.LONDON_WINDOW
        12 -> TradeWindowSession.PRE_NY
        in 13..15 -> TradeWindowSession.NY_WINDOW
        16, 17 -> TradeWindowSession.CUT_TRADING
        18 -> TradeWindowSession.EOD_REVIEW
        else -> TradeWindowSession.OFF_HOURS
      }
    }

    fun createDefaultEconomicCalendar(): List<EconomicNewsEvent> {
      val now = System.currentTimeMillis()
      return listOf(
        EconomicNewsEvent(
          id = "NEWS_1",
          title = "US Core CPI (Consumer Price Index) m/m",
          currency = "USD",
          impact = NewsImpact.HIGH_RED_FOLDER,
          scheduledTimeMillis = now + (45 * 60 * 1000L), // in 45 minutes
          forecast = "0.3%",
          previous = "0.2%"
        ),
        EconomicNewsEvent(
          id = "NEWS_2",
          title = "FOMC Federal Funds Rate Decision",
          currency = "USD",
          impact = NewsImpact.HIGH_RED_FOLDER,
          scheduledTimeMillis = now + (180 * 60 * 1000L), // in 3 hours
          forecast = "5.25%",
          previous = "5.25%"
        ),
        EconomicNewsEvent(
          id = "NEWS_3",
          title = "Non-Farm Employment Change (NFP)",
          currency = "USD",
          impact = NewsImpact.HIGH_RED_FOLDER,
          scheduledTimeMillis = now + (360 * 60 * 1000L), // in 6 hours
          forecast = "180K",
          previous = "216K"
        ),
        EconomicNewsEvent(
          id = "NEWS_4",
          title = "ECB Monetary Policy Statement & Press Conference",
          currency = "EUR",
          impact = NewsImpact.HIGH_RED_FOLDER,
          scheduledTimeMillis = now + (720 * 60 * 1000L),
          forecast = "4.50%",
          previous = "4.50%"
        )
      )
    }
  }

  fun toggleSimulateNewsLock() {
    val now = System.currentTimeMillis()
    val isCurrentlyActive = _activeNewsBlackout.value != null
    if (isCurrentlyActive) {
      // Clear simulated blackout
      _activeNewsBlackout.value = null
      _circuitBreakerHaltReason.value = null
      // Reset news to far away
      _upcomingNews.value = createDefaultEconomicCalendar()
    } else {
      // Simulate High Impact US CPI News exactly in 12 minutes (inside the 30-min blackout window!)
      val simulatedEvent = EconomicNewsEvent(
        id = "SIMULATED_CPI",
        title = "US Core CPI (High Impact Red Folder)",
        currency = "USD",
        impact = NewsImpact.HIGH_RED_FOLDER,
        scheduledTimeMillis = now + (12 * 60 * 1000L), // 12 minutes away (< 30 min)
        forecast = "0.4%",
        previous = "0.3%"
      )
      val updated = mutableListOf(simulatedEvent)
      updated.addAll(createDefaultEconomicCalendar().filter { it.id != "NEWS_1" })
      _upcomingNews.value = updated
      _activeNewsBlackout.value = simulatedEvent
      _circuitBreakerHaltReason.value = "NEWS SHIELD ACTIVE: High-Impact Red Folder '${simulatedEvent.title}' (${simulatedEvent.currency}) in 12m. Strictly NO trading ±30 minutes around news!"
    }
  }
}
