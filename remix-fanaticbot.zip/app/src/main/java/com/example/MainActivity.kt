package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.*
import com.example.data.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.BotNavTab
import com.example.viewmodel.FanaticBotViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: FanaticBotViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme(darkTheme = true) {
        MainAppContent(viewModel = viewModel)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: FanaticBotViewModel) {
  val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
  val settings by viewModel.botSettings.collectAsStateWithLifecycle()
  val selectedPair by viewModel.selectedPair.collectAsStateWithLifecycle()
  val selectedTimeframe by viewModel.selectedTimeframe.collectAsStateWithLifecycle()
  val candles by viewModel.candles.collectAsStateWithLifecycle()
  val orderBlocks by viewModel.orderBlocks.collectAsStateWithLifecycle()
  val fairValueGaps by viewModel.fairValueGaps.collectAsStateWithLifecycle()
  val swingPoints by viewModel.swingPoints.collectAsStateWithLifecycle()
  val structureLines by viewModel.structureLines.collectAsStateWithLifecycle()
  val asianRangeBox by viewModel.asianRangeBox.collectAsStateWithLifecycle()
  val liquidityEvents by viewModel.liquidityEvents.collectAsStateWithLifecycle()
  val pdRange by viewModel.pdRange.collectAsStateWithLifecycle()
  val fibonacci by viewModel.fibonacciRetracement.collectAsStateWithLifecycle()
  val currentSignal by viewModel.currentSignal.collectAsStateWithLifecycle()
  val activePositions by viewModel.activePositions.collectAsStateWithLifecycle()
  val currentWindow by viewModel.currentWindow.collectAsStateWithLifecycle()
  val dailyLossStreak by viewModel.dailyLossStreak.collectAsStateWithLifecycle()
  val dailyLossPercent by viewModel.dailyLossPercent.collectAsStateWithLifecycle()
  val circuitBreakerReason by viewModel.circuitBreakerReason.collectAsStateWithLifecycle()
  val allTrades by viewModel.allTrades.collectAsStateWithLifecycle()
  val todayRoutine by viewModel.todayRoutine.collectAsStateWithLifecycle()
  val checklistState by viewModel.checklistState.collectAsStateWithLifecycle()
  val selectedChapterId by viewModel.selectedChapterId.collectAsStateWithLifecycle()
  val brokerAccount by viewModel.brokerAccount.collectAsStateWithLifecycle()
  val isTestingConnection by viewModel.isTestingConnection.collectAsStateWithLifecycle()
  val connectionTestResult by viewModel.connectionTestResult.collectAsStateWithLifecycle()

  val showOB by viewModel.showOrderBlocks.collectAsStateWithLifecycle()
  val showFVG by viewModel.showFVGs.collectAsStateWithLifecycle()
  val showStructure by viewModel.showStructure.collectAsStateWithLifecycle()
  val showLiquidity by viewModel.showLiquidity.collectAsStateWithLifecycle()
  val showPDRange by viewModel.showPDRange.collectAsStateWithLifecycle()
  val showFibonacci by viewModel.showFibonacci.collectAsStateWithLifecycle()
  val showPatterns by viewModel.showPatterns.collectAsStateWithLifecycle()
  val detectedCandlePatterns by viewModel.detectedCandlePatterns.collectAsStateWithLifecycle()
  val upcomingNews by viewModel.upcomingNews.collectAsStateWithLifecycle()
  val activeNewsBlackout by viewModel.activeNewsBlackout.collectAsStateWithLifecycle()

  BoxWithConstraints(modifier = Modifier.fillMaxSize().background(Slate950)) {
    val isExpanded = maxWidth >= 840.dp

    if (isExpanded) {
      // Desktop / Windows / Widescreen Layout
      Row(modifier = Modifier.fillMaxSize()) {
        // Navigation Rail on the Left (Desktop style)
        NavigationRail(
          containerColor = Slate900,
          contentColor = Slate300,
          header = {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.padding(vertical = 12.dp)
            ) {
              Icon(
                imageVector = Icons.Default.TrendingUp,
                contentDescription = "Logo",
                tint = Emerald500,
                modifier = Modifier.size(28.dp)
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "FanaticBot",
                color = Slate100,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold
              )
              Text(
                text = "Windows / PC",
                color = Emerald400,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          },
          modifier = Modifier.fillMaxHeight().testTag("desktop_nav_rail")
        ) {
          Spacer(modifier = Modifier.height(8.dp))
          BotNavTab.values().forEach { tab ->
            val isSelected = tab == currentTab
            val icon = when (tab) {
              BotNavTab.DASHBOARD -> Icons.Default.CandlestickChart
              BotNavTab.RULES_GUARDIAN -> Icons.Default.Shield
              BotNavTab.BROKER -> Icons.Default.CloudSync
              BotNavTab.JOURNAL -> Icons.Default.FactCheck
              BotNavTab.GOALS_CALC -> Icons.Default.Calculate
              BotNavTab.ROUTINE -> Icons.Default.SelfImprovement
            }

            NavigationRailItem(
              selected = isSelected,
              onClick = { viewModel.setTab(tab) },
              icon = { Icon(imageVector = icon, contentDescription = tab.label) },
              label = { Text(text = tab.label, fontSize = 10.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
              colors = NavigationRailItemDefaults.colors(
                selectedIconColor = Emerald500,
                selectedTextColor = Emerald400,
                unselectedIconColor = Slate400,
                unselectedTextColor = Slate400,
                indicatorColor = Emerald500.copy(alpha = 0.15f)
              ),
              modifier = Modifier.testTag("rail_tab_${tab.name}")
            )
          }

          Spacer(modifier = Modifier.weight(1f))

          // Desktop bottom quick status indicators
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(bottom = 12.dp)
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (brokerAccount.isConnected) Emerald500.copy(alpha = 0.2f) else Slate800)
                .clickable { viewModel.setTab(BotNavTab.BROKER) }
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = if (brokerAccount.isConnected) "MT5: Live" else "MT5: Off",
                color = if (brokerAccount.isConnected) Emerald400 else Slate400,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (settings.effectiveRiskPercent <= 0.15) Amber500.copy(alpha = 0.2f) else Emerald500.copy(alpha = 0.2f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "${String.format("%.2f", settings.effectiveRiskPercent)}% R",
                color = if (settings.effectiveRiskPercent <= 0.15) Amber400 else Emerald400,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        // Desktop Main Content Pane with max width limiter for clean proportions
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .background(Slate950)
            .padding(12.dp)
        ) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .widthIn(max = 1400.dp)
              .align(Alignment.TopCenter)
          ) {
            AppTabContent(
              currentTab = currentTab,
              viewModel = viewModel,
              settings = settings,
              selectedPair = selectedPair,
              selectedTimeframe = selectedTimeframe,
              candles = candles,
              orderBlocks = orderBlocks,
              fairValueGaps = fairValueGaps,
              swingPoints = swingPoints,
              structureLines = structureLines,
              asianRangeBox = asianRangeBox,
              liquidityEvents = liquidityEvents,
              pdRange = pdRange,
              fibonacci = fibonacci,
              currentSignal = currentSignal,
              activePositions = activePositions,
              currentWindow = currentWindow,
              dailyLossPercent = dailyLossPercent,
              dailyLossStreak = dailyLossStreak,
              circuitBreakerReason = circuitBreakerReason,
              upcomingNews = upcomingNews,
              activeNewsBlackout = activeNewsBlackout,
              detectedCandlePatterns = detectedCandlePatterns,
              allTrades = allTrades,
              checklistState = checklistState,
              selectedChapterId = selectedChapterId,
              brokerAccount = brokerAccount,
              isTestingConnection = isTestingConnection,
              connectionTestResult = connectionTestResult,
              todayRoutine = todayRoutine,
              showOB = showOB,
              showFVG = showFVG,
              showStructure = showStructure,
              showLiquidity = showLiquidity,
              showPDRange = showPDRange,
              showFibonacci = showFibonacci,
              showPatterns = showPatterns
            )
          }
        }
      }
    } else {
      // Mobile / Compact Layout
      Scaffold(
        topBar = {
          TopAppBar(
            title = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.TrendingUp,
                  contentDescription = null,
                  tint = Emerald500,
                  modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = "FanaticBot",
                    color = Slate100,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp
                  )
                  Text(
                    text = "SMC Rule-Based Trading Guardian",
                    color = Slate400,
                    fontSize = 10.sp
                  )
                }
              }
            },
            actions = {
              // MT5 status button
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(if (brokerAccount.isConnected) Emerald500.copy(alpha = 0.2f) else Slate800)
                  .clickable { viewModel.setTab(BotNavTab.BROKER) }
                  .padding(horizontal = 8.dp, vertical = 4.dp)
                  .testTag("mt5_topbar_badge")
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.CloudSync,
                    contentDescription = null,
                    tint = if (brokerAccount.isConnected) Emerald400 else Slate400,
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = if (brokerAccount.isConnected) "MT5: Live" else "MT5 Connect",
                    color = if (brokerAccount.isConnected) Emerald400 else Slate400,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                  )
                }
              }

              Spacer(modifier = Modifier.width(6.dp))

              // Effective risk badge
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(if (settings.effectiveRiskPercent <= 0.15) Amber500.copy(alpha = 0.2f) else Emerald500.copy(alpha = 0.2f))
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(
                  text = "Risk: ${String.format("%.2f", settings.effectiveRiskPercent)}%",
                  color = if (settings.effectiveRiskPercent <= 0.15) Amber400 else Emerald400,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Slate950)
          )
        },
        bottomBar = {
          NavigationBar(
            containerColor = Slate950,
            contentColor = Slate300,
            tonalElevation = 8.dp,
            modifier = Modifier.testTag("bottom_nav_bar")
          ) {
            BotNavTab.values().forEach { tab ->
              val isSelected = tab == currentTab
              val icon = when (tab) {
                BotNavTab.DASHBOARD -> Icons.Default.CandlestickChart
                BotNavTab.RULES_GUARDIAN -> Icons.Default.Shield
                BotNavTab.BROKER -> Icons.Default.CloudSync
                BotNavTab.JOURNAL -> Icons.Default.FactCheck
                BotNavTab.GOALS_CALC -> Icons.Default.Calculate
                BotNavTab.ROUTINE -> Icons.Default.SelfImprovement
              }

              NavigationBarItem(
                selected = isSelected,
                onClick = { viewModel.setTab(tab) },
                icon = { Icon(imageVector = icon, contentDescription = tab.label) },
                label = { Text(text = tab.label, fontSize = 9.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                  selectedIconColor = Emerald500,
                  selectedTextColor = Emerald400,
                  unselectedIconColor = Slate400,
                  unselectedTextColor = Slate400,
                  indicatorColor = Emerald500.copy(alpha = 0.15f)
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name}")
              )
            }
          }
        }
      ) { innerPadding ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .background(Slate950)
        ) {
          AppTabContent(
            currentTab = currentTab,
            viewModel = viewModel,
            settings = settings,
            selectedPair = selectedPair,
            selectedTimeframe = selectedTimeframe,
            candles = candles,
            orderBlocks = orderBlocks,
            fairValueGaps = fairValueGaps,
            swingPoints = swingPoints,
            structureLines = structureLines,
            asianRangeBox = asianRangeBox,
            liquidityEvents = liquidityEvents,
            pdRange = pdRange,
            fibonacci = fibonacci,
            currentSignal = currentSignal,
            activePositions = activePositions,
            currentWindow = currentWindow,
            dailyLossPercent = dailyLossPercent,
            dailyLossStreak = dailyLossStreak,
            circuitBreakerReason = circuitBreakerReason,
            upcomingNews = upcomingNews,
            activeNewsBlackout = activeNewsBlackout,
            detectedCandlePatterns = detectedCandlePatterns,
            allTrades = allTrades,
            checklistState = checklistState,
            selectedChapterId = selectedChapterId,
            brokerAccount = brokerAccount,
            isTestingConnection = isTestingConnection,
            connectionTestResult = connectionTestResult,
            todayRoutine = todayRoutine,
            showOB = showOB,
            showFVG = showFVG,
            showStructure = showStructure,
            showLiquidity = showLiquidity,
            showPDRange = showPDRange,
            showFibonacci = showFibonacci,
            showPatterns = showPatterns
          )
        }
      }
    }
  }
}

@Composable
private fun AppTabContent(
  currentTab: BotNavTab,
  viewModel: FanaticBotViewModel,
  settings: com.example.data.BotSettingsEntity,
  selectedPair: String,
  selectedTimeframe: Timeframe,
  candles: List<com.example.model.Candle>,
  orderBlocks: List<com.example.model.OrderBlock>,
  fairValueGaps: List<com.example.model.FairValueGap>,
  swingPoints: List<com.example.model.SwingPoint>,
  structureLines: List<com.example.model.StructureLine>,
  asianRangeBox: com.example.model.AsianRangeBox?,
  liquidityEvents: List<com.example.model.LiquidityEvent>,
  pdRange: com.example.model.PDRange?,
  fibonacci: com.example.model.FibonacciRetracement?,
  currentSignal: com.example.model.TradingSignal?,
  activePositions: List<com.example.model.ActivePosition>,
  currentWindow: com.example.model.TradeWindowSession,
  dailyLossPercent: Double,
  dailyLossStreak: Int,
  circuitBreakerReason: String?,
  upcomingNews: List<com.example.model.EconomicNewsEvent>,
  activeNewsBlackout: com.example.model.EconomicNewsEvent?,
  detectedCandlePatterns: List<com.example.model.DetectedCandlePattern>,
  allTrades: List<TradeEntity>,
  checklistState: Map<String, Boolean>,
  selectedChapterId: String?,
  brokerAccount: BrokerAccountEntity,
  isTestingConnection: Boolean,
  connectionTestResult: String?,
  todayRoutine: RoutineEntity,
  showOB: Boolean,
  showFVG: Boolean,
  showStructure: Boolean,
  showLiquidity: Boolean,
  showPDRange: Boolean,
  showFibonacci: Boolean,
  showPatterns: Boolean
) {
  when (currentTab) {
    BotNavTab.DASHBOARD -> {
      BotDashboardScreen(
        settings = settings,
        selectedPair = selectedPair,
        selectedTimeframe = selectedTimeframe,
        candles = candles,
        orderBlocks = orderBlocks,
        fairValueGaps = fairValueGaps,
        swingPoints = swingPoints,
        structureLines = structureLines,
        asianRangeBox = asianRangeBox,
        liquidityEvents = liquidityEvents,
        pdRange = pdRange,
        fibonacci = fibonacci,
        currentSignal = currentSignal,
        activePositions = activePositions,
        currentWindow = currentWindow,
        dailyLossPercent = dailyLossPercent,
        dailyLossStreak = dailyLossStreak,
        circuitBreakerReason = circuitBreakerReason,
        upcomingNews = upcomingNews,
        activeNewsBlackout = activeNewsBlackout,
        onToggleSimulateNewsLock = { viewModel.toggleSimulateNewsLock() },
        showOB = showOB,
        showFVG = showFVG,
        showStructure = showStructure,
        showLiquidity = showLiquidity,
        showPDRange = showPDRange,
        showFibonacci = showFibonacci,
        candlePatterns = detectedCandlePatterns,
        showPatterns = showPatterns,
        onToggleOB = { viewModel.showOrderBlocks.value = !viewModel.showOrderBlocks.value },
        onToggleFVG = { viewModel.showFVGs.value = !viewModel.showFVGs.value },
        onToggleStructure = { viewModel.showStructure.value = !viewModel.showStructure.value },
        onToggleLiquidity = { viewModel.showLiquidity.value = !viewModel.showLiquidity.value },
        onTogglePDRange = { viewModel.showPDRange.value = !viewModel.showPDRange.value },
        onToggleFibonacci = { viewModel.showFibonacci.value = !viewModel.showFibonacci.value },
        onTogglePatterns = { viewModel.showPatterns.value = !viewModel.showPatterns.value },
        onToggleAutoTrading = { viewModel.toggleAutoTrading() },
        onSelectPair = { viewModel.selectPair(it) },
        onSelectTimeframe = { viewModel.selectTimeframe(it) },
        onScanForSignal = { viewModel.scanForSignal() },
        onExecuteSignal = { viewModel.executeCurrentSignal() },
        onDismissSignal = { viewModel.dismissSignal() },
        onTakePartials = { viewModel.takePartials(it) },
        onMoveBreakeven = { viewModel.moveBreakeven(it) },
        onClosePosition = { viewModel.closePosition(it) },
        onViewAllRules = { viewModel.setTab(BotNavTab.RULES_GUARDIAN) }
      )
    }
    BotNavTab.RULES_GUARDIAN -> {
      RuleGuardianScreen(
        settings = settings,
        dailyLossPercent = dailyLossPercent,
        dailyLossStreak = dailyLossStreak,
        currentWindow = currentWindow,
        circuitBreakerReason = circuitBreakerReason,
        checklistState = checklistState,
        selectedChapterId = selectedChapterId,
        onToggleChecklistItem = { viewModel.toggleChecklistItem(it) },
        onResetChecklist = { viewModel.resetChecklist() },
        onSelectChapter = { viewModel.selectChapter(it) }
      )
    }
    BotNavTab.BROKER -> {
      BrokerConnectScreen(
        brokerAccount = brokerAccount,
        onSaveAccount = { viewModel.saveBrokerAccount(it) },
        onTestConnection = { url, token -> viewModel.testBrokerConnection(url, token) },
        isTestingConnection = isTestingConnection,
        connectionTestResult = connectionTestResult,
        onSendTestOrder = { viewModel.sendTestBrokerOrder() }
      )
    }
    BotNavTab.JOURNAL -> {
      JournalScreen(
        trades = allTrades,
        onDeleteTrade = { tradeId ->
          viewModel.deleteTrade(tradeId)
        }
      )
    }
    BotNavTab.GOALS_CALC -> {
      GoalsCalcScreen()
    }
    BotNavTab.ROUTINE -> {
      RoutineScreen(
        routine = todayRoutine,
        currentWindow = currentWindow,
        onToggleRoutine = { viewModel.toggleRoutine(it) },
        onSetMindsetRating = { viewModel.setMindsetRating(it) }
      )
    }
  }
}
