package com.example.data.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query

interface Mt5BridgeApi {

  @GET("ping")
  suspend fun pingServer(): Response<Void>

  @GET("account")
  suspend fun getAccountStatus(
    @Header("Authorization") authHeader: String?
  ): Response<Mt5AccountResponse>

  @POST("trade")
  suspend fun executeTrade(
    @Header("Authorization") authHeader: String?,
    @Body request: Mt5OrderRequest
  ): Response<Mt5OrderResponse>

  @POST("close")
  suspend fun closePosition(
    @Header("Authorization") authHeader: String?,
    @Query("ticket") ticket: Long
  ): Response<Mt5OrderResponse>
}
