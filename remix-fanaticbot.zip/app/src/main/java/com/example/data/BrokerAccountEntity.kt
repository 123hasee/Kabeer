package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "broker_account")
data class BrokerAccountEntity(
  @PrimaryKey val id: Int = 1,
  val brokerName: String = "MetaTrader 5 (MT5)",
  val connectionType: String = "REST_BRIDGE", // "REST_BRIDGE" (Python/EA Webhook) or "META_API"
  val serverUrl: String = "https://mt5-bridge.example.com", // User's VPS / Webhook endpoint
  val accountLogin: Long = 50928124L,
  val apiToken: String = "",
  val magicNumber: Long = 777999L,
  val isConnected: Boolean = false,
  val lastSyncTimestamp: Long = 0L,
  val serverPingMs: Long = 42L,
  val liveBalance: Double = 30000.0,
  val liveEquity: Double = 30000.0,
  val brokerServer: String = "MetaQuotes-Demo",
  val autoSendToBroker: Boolean = true
)
