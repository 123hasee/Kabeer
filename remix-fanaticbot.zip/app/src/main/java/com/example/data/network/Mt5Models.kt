package com.example.data.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Mt5AccountResponse(
  @Json(name = "balance") val balance: Double? = 0.0,
  @Json(name = "equity") val equity: Double? = 0.0,
  @Json(name = "margin") val margin: Double? = 0.0,
  @Json(name = "free_margin") val freeMargin: Double? = 0.0,
  @Json(name = "currency") val currency: String? = "USD",
  @Json(name = "leverage") val leverage: Int? = 100,
  @Json(name = "broker") val broker: String? = "MetaQuotes Software",
  @Json(name = "server") val server: String? = "Demo Server",
  @Json(name = "login") val login: Long? = 0,
  @Json(name = "connected") val connected: Boolean? = true
)

@JsonClass(generateAdapter = true)
data class Mt5OrderRequest(
  @Json(name = "action") val action: String,       // "BUY" or "SELL"
  @Json(name = "symbol") val symbol: String,       // e.g. "EURUSD"
  @Json(name = "volume") val volume: Double,       // Lots
  @Json(name = "stop_loss") val stopLoss: Double,  // SL price
  @Json(name = "take_profit") val takeProfit: Double, // TP price
  @Json(name = "magic") val magic: Long = 777999L,
  @Json(name = "comment") val comment: String = "FanaticBot-SMC"
)

@JsonClass(generateAdapter = true)
data class Mt5OrderResponse(
  @Json(name = "success") val success: Boolean = true,
  @Json(name = "order_id") val orderId: Long? = null,
  @Json(name = "deal_id") val dealId: Long? = null,
  @Json(name = "message") val message: String? = null,
  @Json(name = "price") val executionPrice: Double? = null
)
