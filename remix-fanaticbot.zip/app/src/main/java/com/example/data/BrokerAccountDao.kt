package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BrokerAccountDao {
  @Query("SELECT * FROM broker_account WHERE id = 1 LIMIT 1")
  fun getBrokerAccount(): Flow<BrokerAccountEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdate(account: BrokerAccountEntity)

  @Update
  suspend fun update(account: BrokerAccountEntity)
}
