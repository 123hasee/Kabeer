package com.example.data.network

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class Mt5Client {

  private val moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

  private val okHttpClient = OkHttpClient.Builder()
    .connectTimeout(8, TimeUnit.SECONDS)
    .readTimeout(8, TimeUnit.SECONDS)
    .writeTimeout(8, TimeUnit.SECONDS)
    .addInterceptor(HttpLoggingInterceptor().apply {
      level = HttpLoggingInterceptor.Level.BODY
    })
    .build()

  private fun getApi(baseUrl: String): Mt5BridgeApi {
    val cleanUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
    return Retrofit.Builder()
      .baseUrl(cleanUrl)
      .client(okHttpClient)
      .addConverterFactory(MoshiConverterFactory.create(moshi))
      .build()
      .create(Mt5BridgeApi::class.java)
  }

  suspend fun testConnection(serverUrl: String, token: String?): Result<Mt5AccountResponse> {
    return withContext(Dispatchers.IO) {
      try {
        val auth = if (!token.isNullOrBlank()) "Bearer $token" else null
        val api = getApi(serverUrl)
        val startTime = System.currentTimeMillis()
        val response = api.getAccountStatus(auth)
        val latency = System.currentTimeMillis() - startTime

        if (response.isSuccessful && response.body() != null) {
          Result.success(response.body()!!)
        } else {
          Result.failure(Exception("HTTP ${response.code()}: ${response.message()}"))
        }
      } catch (e: Exception) {
        Result.failure(e)
      }
    }
  }

  suspend fun fetchAccount(serverUrl: String, token: String?): Result<Mt5AccountResponse> {
    return withContext(Dispatchers.IO) {
      try {
        val auth = if (!token.isNullOrBlank()) "Bearer $token" else null
        val response = getApi(serverUrl).getAccountStatus(auth)
        if (response.isSuccessful && response.body() != null) {
          Result.success(response.body()!!)
        } else {
          Result.failure(Exception("Error ${response.code()}: ${response.message()}"))
        }
      } catch (e: Exception) {
        Result.failure(e)
      }
    }
  }

  suspend fun sendOrder(serverUrl: String, token: String?, request: Mt5OrderRequest): Result<Mt5OrderResponse> {
    return withContext(Dispatchers.IO) {
      try {
        val auth = if (!token.isNullOrBlank()) "Bearer $token" else null
        val response = getApi(serverUrl).executeTrade(auth, request)
        if (response.isSuccessful && response.body() != null) {
          Result.success(response.body()!!)
        } else {
          Result.failure(Exception("Order error ${response.code()}: ${response.errorBody()?.string()}"))
        }
      } catch (e: Exception) {
        Result.failure(e)
      }
    }
  }
}
