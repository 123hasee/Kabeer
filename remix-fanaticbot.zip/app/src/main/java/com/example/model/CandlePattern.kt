package com.example.model

enum class CandlePatternType(
  val label: String,
  val isBullish: Boolean,
  val icon: String,
  val significance: String
) {
  BULLISH_ENGULFING(
    "Bullish Engulfing",
    true,
    "📈",
    "Institutional demand engulfed prior selling candle with strong body close"
  ),
  BEARISH_ENGULFING(
    "Bearish Engulfing",
    false,
    "📉",
    "Institutional supply engulfed prior buying candle with aggressive downward close"
  ),
  BULLISH_PIN_BAR(
    "Rejection Pin Bar (Sweep Wick)",
    true,
    "🔨",
    "Long lower wick swept sell-side liquidity (SSL) and rejected aggressively upward"
  ),
  BEARISH_PIN_BAR(
    "Shooting Star / Upper Rejection",
    false,
    "⭐",
    "Long upper wick swept buy-side liquidity (BSL) and slammed price down"
  ),
  MORNING_STAR(
    "Morning Star Reversal",
    true,
    "🌅",
    "3-Candle exhaustion at Order Block followed by impulsive bullish displacement"
  ),
  EVENING_STAR(
    "Evening Star Reversal",
    false,
    "🌆",
    "3-Candle exhaustion at Supply zone followed by impulsive bearish displacement"
  ),
  BULLISH_MOMENTUM(
    "Bullish Expansion (Imbalance)",
    true,
    "⚡",
    "Strong institutional green candle creating Fair Value Gap (FVG)"
  ),
  BEARISH_MOMENTUM(
    "Bearish Expansion (Imbalance)",
    false,
    "⚡",
    "Strong institutional red candle creating Fair Value Gap (FVG)"
  ),
  NONE(
    "Standard Candle",
    true,
    "•",
    "Indecision or standard range without clear institutional confirmation"
  )
}

data class DetectedCandlePattern(
  val pattern: CandlePatternType,
  val candleIndex: Int,
  val price: Double,
  val isBullish: Boolean,
  val description: String,
  val isConfirmedForEntry: Boolean = true
)
