package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun CandlestickChart(
  candles: List<Candle>,
  orderBlocks: List<OrderBlock>,
  fairValueGaps: List<FairValueGap>,
  swingPoints: List<SwingPoint>,
  structureLines: List<StructureLine>,
  asianRangeBox: AsianRangeBox?,
  liquidityEvents: List<LiquidityEvent>,
  pdRange: PDRange?,
  fibonacci: FibonacciRetracement? = null,
  candlePatterns: List<DetectedCandlePattern> = emptyList(),
  symbol: String,
  showOB: Boolean = true,
  showFVG: Boolean = true,
  showStructure: Boolean = true,
  showLiquidity: Boolean = true,
  showPDRange: Boolean = true,
  showFibonacci: Boolean = true,
  showPatterns: Boolean = true,
  modifier: Modifier = Modifier
) {
  val textMeasurer = rememberTextMeasurer()

  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(300.dp)
      .clip(RoundedCornerShape(12.dp))
      .background(Slate900)
      .testTag("candlestick_chart_container")
  ) {
    if (candles.isEmpty()) {
      Text(
        text = "Loading auto levels for $symbol...",
        color = Slate400,
        modifier = Modifier.align(Alignment.Center)
      )
      return@Box
    }

    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 8.dp, vertical = 12.dp)
        .testTag("candlestick_canvas")
    ) {
      val canvasWidth = size.width
      val canvasHeight = size.height
      val rightAxisWidth = 65f
      val plotWidth = canvasWidth - rightAxisWidth

      val topMargin = 22f
      val bottomMargin = 26f
      val usablePlotHeight = (canvasHeight - topMargin - bottomMargin).coerceAtLeast(20f)

      val minPrice = candles.minOf { it.low }
      val maxPrice = candles.maxOf { it.high }
      val priceSpan = (maxPrice - minPrice).coerceAtLeast(0.0001)

      fun priceToY(price: Double): Float {
        val normalized = ((price - minPrice) / priceSpan).coerceIn(0.0, 1.0)
        return (canvasHeight - bottomMargin - (normalized * usablePlotHeight)).toFloat()
      }

      val candleCount = candles.size
      val candleSpacing = plotWidth / candleCount
      val candleBodyWidth = (candleSpacing * 0.65f).coerceAtLeast(3f)

      fun indexToX(index: Int): Float {
        val clamped = index.coerceIn(0, candleCount - 1)
        return (clamped * candleSpacing) + (candleSpacing / 2f)
      }

      // Safe text drawing helper to strictly prevent Constraints maxHeight < minHeight crashes
      fun safeDraw(
        text: String,
        x: Float,
        y: Float,
        color: Color,
        fontSize: TextUnit,
        fontWeight: FontWeight = FontWeight.Normal
      ) {
        val minRemaining = 16f
        val safeX = x.coerceIn(2f, (canvasWidth - 30f).coerceAtLeast(2f))
        val safeY = y.coerceIn(2f, (canvasHeight - minRemaining).coerceAtLeast(2f))

        try {
          drawText(
            textMeasurer = textMeasurer,
            text = text,
            topLeft = Offset(safeX, safeY),
            style = TextStyle(color = color, fontSize = fontSize, fontWeight = fontWeight)
          )
        } catch (_: Exception) {
          // Guard against any unforeseen layout constraint exceptions
        }
      }

      // 1. Gridlines & Right Axis Price Labels
      val gridSteps = 4
      for (i in 0..gridSteps) {
        val p = minPrice + (priceSpan / gridSteps) * i
        val y = priceToY(p)
        drawLine(
          color = Slate800,
          start = Offset(0f, y),
          end = Offset(plotWidth, y),
          strokeWidth = 1f
        )
        val formatted = if (symbol == "US30") String.format("%.0f", p) else String.format("%.5f", p)
        safeDraw(
          text = formatted,
          x = plotWidth + 6f,
          y = y - 7f,
          color = Slate400,
          fontSize = 9.sp
        )
      }

      // 2. Asian Range Box (01:00 - 05:00 GMT Accumulation Phase)
      if (showLiquidity && asianRangeBox != null) {
        val startX = 0f
        val endX = indexToX(asianRangeBox.endIndex)
        val boxTopY = priceToY(asianRangeBox.high)
        val boxBottomY = priceToY(asianRangeBox.low)
        val boxH = (boxBottomY - boxTopY).coerceAtLeast(4f)

        // Shaded session box
        drawRect(
          color = AsianRangeColor,
          topLeft = Offset(startX, boxTopY),
          size = Size(endX - startX, boxH)
        )
        drawRect(
          color = Purple500.copy(alpha = 0.5f),
          topLeft = Offset(startX, boxTopY),
          size = Size(endX - startX, boxH),
          style = Stroke(width = 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f))
        )
        safeDraw(
          text = "Asian Range (01:00-05:00 GMT)",
          x = 4f,
          y = boxTopY + 2f,
          color = Purple500,
          fontSize = 8.sp,
          fontWeight = FontWeight.SemiBold
        )
      }

      // 3. Premium / Discount 50% Equilibrium Line
      if (showPDRange && pdRange != null) {
        val eqY = priceToY(pdRange.equilibrium)
        val dashedEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)

        drawLine(
          color = EquilibriumColor.copy(alpha = 0.85f),
          start = Offset(0f, eqY),
          end = Offset(plotWidth, eqY),
          strokeWidth = 1.8f,
          pathEffect = dashedEffect
        )

        safeDraw(
          text = "50% EQ (${String.format(if (symbol == "US30") "%.0f" else "%.4f", pdRange.equilibrium)})",
          x = 8f,
          y = eqY - 14f,
          color = EquilibriumColor,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold
        )

        safeDraw(
          text = "PREMIUM (Sell)",
          x = plotWidth - 85f,
          y = 4f,
          color = Rose400.copy(alpha = 0.7f),
          fontSize = 8.sp,
          fontWeight = FontWeight.Bold
        )

        safeDraw(
          text = "DISCOUNT (Buy)",
          x = plotWidth - 85f,
          y = canvasHeight - 20f,
          color = Emerald400.copy(alpha = 0.7f),
          fontSize = 8.sp,
          fontWeight = FontWeight.Bold
        )
      }

      // 3.5 Fibonacci Retracement & Optimal Trade Entry (OTE 0.618 - 0.786)
      if (showFibonacci && fibonacci != null) {
        val y618 = priceToY(fibonacci.level618)
        val y786 = priceToY(fibonacci.level786)
        val oteTop = minOf(y618, y786)
        val oteBottom = maxOf(y618, y786)
        val oteH = (oteBottom - oteTop).coerceAtLeast(3f)

        // Shaded Golden OTE Zone (Institutional Entry Area)
        drawRect(
          color = Amber500.copy(alpha = 0.13f),
          topLeft = Offset(0f, oteTop),
          size = Size(plotWidth, oteH)
        )
        drawRect(
          color = Amber500.copy(alpha = 0.4f),
          topLeft = Offset(0f, oteTop),
          size = Size(plotWidth, oteH),
          style = Stroke(width = 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f))
        )

        // 70.5% Institutional Sweet Spot line
        val y705 = priceToY(fibonacci.level705)
        drawLine(
          color = Amber400,
          start = Offset(0f, y705),
          end = Offset(plotWidth, y705),
          strokeWidth = 1.6f,
          pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f)
        )

        safeDraw(
          text = "★ 70.5% OTE Sweet Spot (${String.format(if (symbol == "US30") "%.0f" else "%.4f", fibonacci.level705)})",
          x = 8f,
          y = y705 - 12f,
          color = Amber400,
          fontSize = 8.sp,
          fontWeight = FontWeight.ExtraBold
        )

        safeDraw(
          text = "Fib 61.8%",
          x = plotWidth - 55f,
          y = y618 - 11f,
          color = Amber400.copy(alpha = 0.85f),
          fontSize = 8.sp,
          fontWeight = FontWeight.SemiBold
        )

        safeDraw(
          text = "Fib 78.6%",
          x = plotWidth - 55f,
          y = y786 + 1f,
          color = Amber400.copy(alpha = 0.85f),
          fontSize = 8.sp,
          fontWeight = FontWeight.SemiBold
        )
      }

      // 4. Order Blocks (OB) Auto-Marked
      if (showOB) {
        for (ob in orderBlocks) {
          val topY = priceToY(ob.topPrice)
          val bottomY = priceToY(ob.bottomPrice)
          val obH = (bottomY - topY).coerceAtLeast(4f)
          val midY = priceToY(ob.equilibrium50)

          val isDemand = ob.type == OrderBlockType.BULLISH_DEMAND
          val fillCol = if (isDemand) DemandZoneColor else SupplyZoneColor
          val borderCol = if (isDemand) DemandZoneBorder else SupplyZoneBorder

          drawRect(
            color = fillCol,
            topLeft = Offset(0f, topY),
            size = Size(plotWidth, obH)
          )
          drawRect(
            color = borderCol,
            topLeft = Offset(0f, topY),
            size = Size(plotWidth, obH),
            style = Stroke(width = 1.5f)
          )

          // 50% OB equilibrium entry line
          drawLine(
            color = borderCol.copy(alpha = 0.9f),
            start = Offset(0f, midY),
            end = Offset(plotWidth, midY),
            strokeWidth = 1f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
          )

          val label = if (isDemand) "+Demand OB (50% Entry)" else "-Supply OB (50% Entry)"
          safeDraw(
            text = label,
            x = 8f,
            y = topY + 2f,
            color = borderCol,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      // 5. Fair Value Gaps (FVG / Imbalances) Auto-Marked
      if (showFVG) {
        for (fvg in fairValueGaps) {
          val topY = priceToY(fvg.topPrice)
          val bottomY = priceToY(fvg.bottomPrice)
          val fvgH = (bottomY - topY).coerceAtLeast(3f)
          val ceY = priceToY(fvg.consequentEncroachment)

          val startX = indexToX(fvg.startIndex)
          val endX = indexToX(fvg.endIndex).coerceAtMost(plotWidth)
          val fvgWidth = (endX - startX).coerceAtLeast(30f)

          val fvgColor = if (fvg.isBullish) Emerald500.copy(alpha = 0.18f) else Rose500.copy(alpha = 0.18f)
          val fvgBorder = if (fvg.isBullish) Emerald400 else Rose400

          drawRect(
            color = fvgColor,
            topLeft = Offset(startX, topY),
            size = Size(fvgWidth, fvgH)
          )
          drawRect(
            color = fvgBorder.copy(alpha = 0.6f),
            topLeft = Offset(startX, topY),
            size = Size(fvgWidth, fvgH),
            style = Stroke(width = 1f)
          )

          // 50% Consequent Encroachment (C.E.) line
          drawLine(
            color = fvgBorder.copy(alpha = 0.7f),
            start = Offset(startX, ceY),
            end = Offset(startX + fvgWidth, ceY),
            strokeWidth = 1f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
          )

          val tag = if (fvg.isBullish) "+FVG (C.E. 50%)" else "-FVG (C.E. 50%)"
          safeDraw(
            text = tag,
            x = startX + 4f,
            y = topY + 1f,
            color = fvgBorder,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      // 6. Structure Breaks (SB) & Trend Changes (TC)
      if (showStructure) {
        for (line in structureLines) {
          val y = priceToY(line.price)
          val startX = indexToX(line.startIndex)
          val endX = indexToX(line.endIndex).coerceAtMost(plotWidth)
          val col = if (line.type == FormationType.TC) Amber400 else Blue500

          drawLine(
            color = col,
            start = Offset(startX, y),
            end = Offset(endX, y),
            strokeWidth = 1.5f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f)
          )

          safeDraw(
            text = line.label,
            x = startX + 6f,
            y = y - 12f,
            color = col,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      // 7. Candlesticks Rendering
      candles.forEachIndexed { index, candle ->
        val xCenter = indexToX(index)
        val highY = priceToY(candle.high)
        val lowY = priceToY(candle.low)
        val openY = priceToY(candle.open)
        val closeY = priceToY(candle.close)

        val candleColor = if (candle.isBullish) Emerald500 else Rose500

        // Wick
        drawLine(
          color = candleColor,
          start = Offset(xCenter, highY),
          end = Offset(xCenter, lowY),
          strokeWidth = 1.5f
        )

        // Body
        val bodyTopY = minOf(openY, closeY)
        val bodyHeight = (abs(openY - closeY)).coerceAtLeast(2f)

        drawRect(
          color = candleColor,
          topLeft = Offset(xCenter - (candleBodyWidth / 2f), bodyTopY),
          size = Size(candleBodyWidth, bodyHeight)
        )
      }

      // 8. Swing Points (Strong Low, Weak High, HH, HL)
      if (showStructure) {
        for (sp in swingPoints) {
          val x = indexToX(sp.index)
          val y = priceToY(sp.price)
          val isHigh = sp.isHigh

          // Point dot
          val dotCol = if (sp.isStrong) Emerald400 else if (sp.isWeak) Cyan500 else Slate300
          drawCircle(
            color = dotCol,
            radius = 3.5f,
            center = Offset(x, y)
          )

          // Label text
          val textY = if (isHigh) y - 14f else y + 2f
          safeDraw(
            text = sp.label,
            x = x - 18f,
            y = textY,
            color = dotCol,
            fontSize = 8.sp,
            fontWeight = if (sp.isStrong || sp.isWeak) FontWeight.ExtraBold else FontWeight.SemiBold
          )
        }
      }

      // 9. Liquidity Grabs (LG Sweeps)
      if (showLiquidity) {
        for (event in liquidityEvents) {
          if (event.type == LiquidityType.LIQUIDITY_GRAB) {
            val y = priceToY(event.price)
            // Draw sweep text badge under candle 10
            val sweepX = indexToX(10)
            drawLine(
              color = Amber400,
              start = Offset(sweepX - 15f, y + 6f),
              end = Offset(sweepX + 15f, y + 6f),
              strokeWidth = 2f
            )
            safeDraw(
              text = "LG Sweep (Stop Hunt)",
              x = sweepX - 35f,
              y = y + 8f,
              color = Amber400,
              fontSize = 8.sp,
              fontWeight = FontWeight.Bold
            )
          } else if (event.type == LiquidityType.EQH) {
            val y = priceToY(event.price)
            safeDraw(
              text = "$$$ Equal Highs (EQH)",
              x = plotWidth - 110f,
              y = y - 12f,
              color = Cyan500,
              fontSize = 8.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      // 10. Candlestick Pattern Recognition Markers (Engulfing, Pin Bars, Reversals)
      if (showPatterns) {
        for (dp in candlePatterns) {
          if (dp.candleIndex in candles.indices) {
            val x = indexToX(dp.candleIndex)
            val candle = candles[dp.candleIndex]
            val isBullish = dp.isBullish
            val y = if (isBullish) priceToY(candle.low) + 12f else priceToY(candle.high) - 16f
            val badgeCol = if (isBullish) Emerald400 else Rose400

            safeDraw(
              text = "${dp.pattern.icon} ${dp.pattern.label}",
              x = x - 32f,
              y = y,
              color = badgeCol,
              fontSize = 7.5.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}
