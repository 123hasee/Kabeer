package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BrokerAccountEntity
import com.example.ui.theme.*

@Composable
fun BrokerConnectScreen(
  brokerAccount: BrokerAccountEntity,
  onSaveAccount: (BrokerAccountEntity) -> Unit,
  onTestConnection: (String, String?) -> Unit,
  isTestingConnection: Boolean,
  connectionTestResult: String?,
  onSendTestOrder: () -> Unit,
  modifier: Modifier = Modifier
) {
  var serverUrl by remember(brokerAccount) { mutableStateOf(brokerAccount.serverUrl) }
  var accountLogin by remember(brokerAccount) { mutableStateOf(brokerAccount.accountLogin.toString()) }
  var apiToken by remember(brokerAccount) { mutableStateOf(brokerAccount.apiToken) }
  var magicNumber by remember(brokerAccount) { mutableStateOf(brokerAccount.magicNumber.toString()) }
  var autoSend by remember(brokerAccount) { mutableStateOf(brokerAccount.autoSendToBroker) }
  var selectedType by remember(brokerAccount) { mutableStateOf(brokerAccount.connectionType) }
  var showSetupGuide by remember { mutableStateOf(false) }

  val clipboardManager: ClipboardManager = LocalClipboardManager.current
  var copiedNotice by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(Slate950)
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item { Spacer(modifier = Modifier.height(4.dp)) }

    // Header Title
    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.CloudSync,
          contentDescription = null,
          tint = Emerald500,
          modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          Text(
            text = "MetaTrader 5 & Broker Connection",
            color = Slate100,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )
          Text(
            text = "Connect FanaticBot to MT5, FTMO, or Prop Firm terminal",
            color = Slate400,
            fontSize = 11.sp
          )
        }
      }
    }

    // Live Broker Status Card
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = androidx.compose.ui.graphics.SolidColor(
            if (brokerAccount.isConnected) Emerald500.copy(alpha = 0.6f) else Amber500.copy(alpha = 0.4f)
          )
        ),
        modifier = Modifier.fillMaxWidth().testTag("broker_status_card")
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(10.dp)
                  .clip(CircleShape)
                  .background(if (brokerAccount.isConnected) Emerald500 else Rose500)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (brokerAccount.isConnected) "MT5 TERMINAL CONNECTED" else "DISCONNECTED",
                color = if (brokerAccount.isConnected) Emerald400 else Rose400,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(Slate800)
                .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Text(
                text = "Ping: ${brokerAccount.serverPingMs}ms",
                color = if (brokerAccount.serverPingMs < 60) Emerald400 else Amber400,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(text = "LIVE MT5 BALANCE", color = Slate400, fontSize = 10.sp)
              Text(
                text = "$${String.format("%,.2f", brokerAccount.liveBalance)}",
                color = Slate100,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(text = "SERVER / BROKER", color = Slate400, fontSize = 10.sp)
              Text(
                text = brokerAccount.brokerServer,
                color = Blue500,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Login #${brokerAccount.accountLogin}",
                color = Slate400,
                fontSize = 10.sp
              )
            }
          }

          if (connectionTestResult != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(Slate800)
                .padding(8.dp)
            ) {
              Text(
                text = connectionTestResult,
                color = if (connectionTestResult.contains("Success", ignoreCase = true) || connectionTestResult.contains("Connected", ignoreCase = true)) Emerald400 else Amber400,
                fontSize = 11.sp
              )
            }
          }
        }
      }
    }

    // Connection Configuration Form
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(text = "BRIDGE CONFIGURATION", color = Slate100, fontWeight = FontWeight.Bold, fontSize = 12.sp)

          // Bridge Type Selector
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf(
              "REST_BRIDGE" to "Python / VPS Bridge",
              "META_API" to "MetaAPI Cloud",
              "WEBHOOK" to "Direct Webhook"
            ).forEach { (type, label) ->
              val isSelected = selectedType == type
              Box(
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSelected) Blue500 else Slate800)
                  .clickable { selectedType = type }
                  .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = label,
                  color = if (isSelected) Color.White else Slate400,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          // Server URL Input
          Column {
            Text(text = "Bridge / Server URL", color = Slate400, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(2.dp))
            OutlinedTextField(
              value = serverUrl,
              onValueChange = { serverUrl = it },
              singleLine = true,
              placeholder = { Text("http://10.0.2.2:5000 or https://your-vps.com:5000", color = Slate600, fontSize = 12.sp) },
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Blue500,
                unfocusedBorderColor = Slate700,
                focusedTextColor = Slate100,
                unfocusedTextColor = Slate100
              ),
              modifier = Modifier.fillMaxWidth().testTag("server_url_input")
            )
          }

          // Account Login & Magic Number Row
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Account Login ID", color = Slate400, fontSize = 11.sp)
              Spacer(modifier = Modifier.height(2.dp))
              OutlinedTextField(
                value = accountLogin,
                onValueChange = { accountLogin = it },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = Blue500,
                  unfocusedBorderColor = Slate700,
                  focusedTextColor = Slate100,
                  unfocusedTextColor = Slate100
                ),
                modifier = Modifier.fillMaxWidth().testTag("account_login_input")
              )
            }

            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Magic Number", color = Slate400, fontSize = 11.sp)
              Spacer(modifier = Modifier.height(2.dp))
              OutlinedTextField(
                value = magicNumber,
                onValueChange = { magicNumber = it },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = Blue500,
                  unfocusedBorderColor = Slate700,
                  focusedTextColor = Slate100,
                  unfocusedTextColor = Slate100
                ),
                modifier = Modifier.fillMaxWidth()
              )
            }
          }

          // API Token (Optional)
          Column {
            Text(text = "API Token / Password (Optional)", color = Slate400, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(2.dp))
            OutlinedTextField(
              value = apiToken,
              onValueChange = { apiToken = it },
              singleLine = true,
              placeholder = { Text("Leave empty if running local bridge", color = Slate600, fontSize = 12.sp) },
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Blue500,
                unfocusedBorderColor = Slate700,
                focusedTextColor = Slate100,
                unfocusedTextColor = Slate100
              ),
              modifier = Modifier.fillMaxWidth()
            )
          }

          // Auto-Send switch
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Auto-Dispatch Bot Trades to MT5", color = Slate100, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
              Text(text = "When signal passes all rules, send order directly to terminal", color = Slate400, fontSize = 10.sp)
            }
            Switch(
              checked = autoSend,
              onCheckedChange = { autoSend = it },
              colors = SwitchDefaults.colors(
                checkedThumbColor = Emerald500,
                checkedTrackColor = Emerald500.copy(alpha = 0.3f),
                uncheckedThumbColor = Slate400,
                uncheckedTrackColor = Slate800
              )
            )
          }

          // Action Buttons: Test & Save
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = { onTestConnection(serverUrl, apiToken) },
              enabled = !isTestingConnection,
              modifier = Modifier.weight(1f).testTag("test_connection_button")
            ) {
              if (isTestingConnection) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Blue500, strokeWidth = 2.dp)
              } else {
                Icon(imageVector = Icons.Default.Sensors, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Test Ping", fontSize = 11.sp)
              }
            }

            Button(
              onClick = {
                val updated = brokerAccount.copy(
                  serverUrl = serverUrl,
                  accountLogin = accountLogin.toLongOrNull() ?: brokerAccount.accountLogin,
                  apiToken = apiToken,
                  magicNumber = magicNumber.toLongOrNull() ?: brokerAccount.magicNumber,
                  connectionType = selectedType,
                  autoSendToBroker = autoSend,
                  isConnected = true,
                  lastSyncTimestamp = System.currentTimeMillis()
                )
                onSaveAccount(updated)
              },
              colors = ButtonDefaults.buttonColors(containerColor = Emerald500),
              modifier = Modifier.weight(1.3f).testTag("save_broker_button")
            ) {
              Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Black)
              Spacer(modifier = Modifier.width(4.dp))
              Text(text = "Save & Connect", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
          }

          // Test Order button
          OutlinedButton(
            onClick = onSendTestOrder,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Blue500),
            modifier = Modifier.fillMaxWidth().testTag("send_test_order_button")
          ) {
            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "Send Test 0.01 Lot Check Order to MT5", fontSize = 11.sp)
          }
        }
      }
    }

    // Free Python MT5 Bridge Setup Guide (Accordion)
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
              .fillMaxWidth()
              .clickable { showSetupGuide = !showSetupGuide }
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = Cyan500, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Free MT5 Python Bridge Script (Run on PC / VPS)",
                color = Slate100,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }
            Icon(
              imageVector = if (showSetupGuide) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
              contentDescription = null,
              tint = Slate400
            )
          }

          AnimatedVisibility(visible = showSetupGuide) {
            Column(modifier = Modifier.padding(top = 10.dp)) {
              Text(
                text = "Copy and run this lightweight Python script on your Windows PC / VPS where MetaTrader 5 is installed. It instantly receives trades from FanaticBot and places them in MT5:",
                color = Slate400,
                fontSize = 11.sp,
                lineHeight = 16.sp
              )

              Spacer(modifier = Modifier.height(8.dp))

              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .background(Slate950)
                  .border(1.dp, Slate800, RoundedCornerShape(8.dp))
                  .padding(10.dp)
              ) {
                Text(
                  text = PYTHON_BRIDGE_CODE,
                  color = Slate300,
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace,
                  lineHeight = 14.sp
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              Button(
                onClick = {
                  clipboardManager.setText(AnnotatedString(PYTHON_BRIDGE_CODE))
                  copiedNotice = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                modifier = Modifier.fillMaxWidth()
              ) {
                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = if (copiedNotice) "Copied to Clipboard!" else "Copy Python Bridge Code", fontSize = 11.sp)
              }
            }
          }
        }
      }
    }

    item { Spacer(modifier = Modifier.height(16.dp)) }
  }
}

private const val PYTHON_BRIDGE_CODE = """# pip install flask MetaTrader5
from flask import Flask, request, jsonify
import MetaTrader5 as mt5

app = Flask(__name__)

if not mt5.initialize():
    print("MT5 initialization failed")

@app.route('/account', methods=['GET'])
def account():
    info = mt5.account_info()
    if info is None:
        return jsonify({"connected": False}), 500
    return jsonify({
        "balance": info.balance,
        "equity": info.equity,
        "currency": info.currency,
        "broker": info.company,
        "server": info.server,
        "login": info.login,
        "connected": True
    })

@app.route('/trade', methods=['POST'])
def trade():
    d = request.json
    action = mt5.ORDER_TYPE_BUY if d['action'] == 'BUY' else mt5.ORDER_TYPE_SELL
    price = mt5.symbol_info_tick(d['symbol']).ask if d['action'] == 'BUY' else mt5.symbol_info_tick(d['symbol']).bid
    req = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": d['symbol'],
        "volume": float(d['volume']),
        "type": action,
        "price": price,
        "sl": float(d['stop_loss']),
        "tp": float(d['take_profit']),
        "magic": int(d.get('magic', 777999)),
        "comment": d.get('comment', "FanaticBot-SMC"),
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    res = mt5.order_send(req)
    return jsonify({"success": res.retcode == mt5.TRADE_RETCODE_DONE, "retcode": res.retcode})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
"""
