package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BotSettingsEntity
import com.example.model.*
import com.example.ui.components.ActivePositionsList
import com.example.ui.components.CandlestickChart
import com.example.ui.components.RuleReminderCard
import com.example.ui.components.TradingSignalCard
import com.example.ui.theme.*

@Composable
fun BotDashboardScreen(
  settings: BotSettingsEntity,
  selectedPair: String,
  selectedTimeframe: Timeframe,
  candles: List<Candle>,
  orderBlocks: List<OrderBlock>,
  fairValueGaps: List<FairValueGap>,
  swingPoints: List<SwingPoint>,
  structureLines: List<StructureLine>,
  asianRangeBox: AsianRangeBox?,
  liquidityEvents: List<LiquidityEvent>,
  pdRange: PDRange?,
  fibonacci: FibonacciRetracement? = null,
  currentSignal: TradingSignal?,
  activePositions: List<ActivePosition>,
  currentWindow: TradeWindowSession,
  dailyLossPercent: Double,
  dailyLossStreak: Int,
  circuitBreakerReason: String?,
  upcomingNews: List<EconomicNewsEvent> = emptyList(),
  activeNewsBlackout: EconomicNewsEvent? = null,
  onToggleSimulateNewsLock: () -> Unit = {},
  showOB: Boolean,
  showFVG: Boolean,
  showStructure: Boolean,
  showLiquidity: Boolean,
  showPDRange: Boolean,
  showFibonacci: Boolean = true,
  candlePatterns: List<DetectedCandlePattern> = emptyList(),
  showPatterns: Boolean = true,
  onToggleOB: () -> Unit,
  onToggleFVG: () -> Unit,
  onToggleStructure: () -> Unit,
  onToggleLiquidity: () -> Unit,
  onTogglePDRange: () -> Unit,
  onToggleFibonacci: () -> Unit = {},
  onTogglePatterns: () -> Unit = {},
  onToggleAutoTrading: () -> Unit,
  onSelectPair: (String) -> Unit,
  onSelectTimeframe: (Timeframe) -> Unit,
  onScanForSignal: () -> Unit,
  onExecuteSignal: () -> Unit,
  onDismissSignal: () -> Unit,
  onTakePartials: (Long) -> Unit,
  onMoveBreakeven: (Long) -> Unit,
  onClosePosition: (Long) -> Unit,
  onViewAllRules: () -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(Slate950)
      .padding(horizontal = 14.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item { Spacer(modifier = Modifier.height(4.dp)) }

    // Header: Account Balance & Bot Status Toggle
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = androidx.compose.ui.graphics.SolidColor(Slate800)
        ),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column {
              Text(text = "TOTAL ACCOUNT BALANCE", color = Slate400, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
              Text(
                text = "$${String.format("%,.2f", settings.balance)}",
                color = Slate100,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold
              )
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "${if (settings.totalProfitPercent >= 0) "+" else ""}${String.format("%.2f", settings.totalProfitPercent)}% total return",
                  color = if (settings.totalProfitPercent >= 0) Emerald400 else Rose400,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "• Peak: $${String.format("%,.0f", settings.peakBalance)}",
                  color = Slate400,
                  fontSize = 11.sp
                )
              }
            }

            // Bot Auto Trading Toggle Switch
            Column(horizontalAlignment = Alignment.End) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (settings.isAutoTradingActive) Emerald500 else Slate600)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (settings.isAutoTradingActive) "BOT ACTIVE" else "PAUSED",
                  color = if (settings.isAutoTradingActive) Emerald400 else Slate400,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp
                )
              }
              Switch(
                checked = settings.isAutoTradingActive,
                onCheckedChange = { onToggleAutoTrading() },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = Emerald500,
                  checkedTrackColor = Emerald500.copy(alpha = 0.3f),
                  uncheckedThumbColor = Slate400,
                  uncheckedTrackColor = Slate800
                ),
                modifier = Modifier.testTag("auto_trading_switch")
              )
            }
          }
        }
      }
    }

    // Rule Reminder Guardian Card
    item {
      RuleReminderCard(
        settings = settings,
        dailyLossPercent = dailyLossPercent,
        dailyLossStreak = dailyLossStreak,
        currentWindow = currentWindow,
        circuitBreakerReason = circuitBreakerReason,
        onViewAllRules = onViewAllRules
      )
    }

    // High Impact News Shield Status Card
    item {
      val nextNews = upcomingNews.firstOrNull { it.impact == NewsImpact.HIGH_RED_FOLDER && it.minutesUntil() > 0 }
      val isBlackoutActive = activeNewsBlackout != null

      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = if (isBlackoutActive) Rose500.copy(alpha = 0.12f) else Slate900),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = androidx.compose.ui.graphics.SolidColor(if (isBlackoutActive) Rose500 else Slate800)
        ),
        modifier = Modifier.fillMaxWidth().testTag("news_shield_card")
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (isBlackoutActive) Icons.Default.Warning else Icons.Default.Shield,
                contentDescription = "News Shield",
                tint = if (isBlackoutActive) Rose500 else Emerald400,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isBlackoutActive) "HIGH-IMPACT NEWS LOCK (±30M)" else "News Shield Active (±30m Red Folder Lock)",
                color = if (isBlackoutActive) Rose400 else Slate100,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }

            TextButton(
              onClick = onToggleSimulateNewsLock,
              contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
              modifier = Modifier.height(26.dp)
            ) {
              Text(
                text = if (isBlackoutActive) "Reset News" else "Simulate News",
                color = if (isBlackoutActive) Amber400 else Blue500,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Spacer(modifier = Modifier.height(4.dp))

          if (isBlackoutActive && activeNewsBlackout != null) {
            val mins = activeNewsBlackout.minutesUntil()
            val timingText = if (mins >= 0) "Release in ${mins}m" else "${kotlin.math.abs(mins)}m since release"
            Text(
              text = "⛔ TRADING STRICTLY BLOCKED: '${activeNewsBlackout.title}' (${activeNewsBlackout.currency}) is active ($timingText).",
              color = Rose400,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
            Text(
              text = "Rule: No new trade 30m before or 30m after red folder news to eliminate slippage & spread spikes.",
              color = Slate400,
              fontSize = 10.sp
            )
          } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(6.dp)
                  .clip(CircleShape)
                  .background(Emerald400)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (nextNews != null) {
                  "Clear to trade • Next Red Folder: ${nextNews.title} (${nextNews.currency}) in ${nextNews.minutesUntil()}m"
                } else {
                  "Clear to trade • No high impact news scheduled in next 24 hours"
                },
                color = Slate300,
                fontSize = 11.sp
              )
            }
          }
        }
      }
    }

    // Pair and Timeframe Selector Row
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Pairs (EURUSD, US30, GBPUSD)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("EURUSD", "US30", "GBPUSD").forEach { pair ->
            val isSelected = pair == selectedPair
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) Blue500 else Slate900)
                .clickable { onSelectPair(pair) }
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .testTag("pair_selector_$pair")
            ) {
              Text(
                text = pair,
                color = if (isSelected) Color.White else Slate300,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
              )
            }
          }
        }

        // Timeframes (4H, 15M, 1M)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Timeframe.values().forEach { tf ->
            val isSelected = tf == selectedTimeframe
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) Emerald500 else Slate900)
                .clickable { onSelectTimeframe(tf) }
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .testTag("tf_selector_${tf.name}")
            ) {
              Text(
                text = tf.label,
                color = if (isSelected) Color.Black else Slate300,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
              )
            }
          }
        }
      }
    }

    // Candlestick Chart with SMC Overlays & Auto Levels
    item {
      Column {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
        ) {
          Text(
            text = "$selectedPair • ${selectedTimeframe.label} (Auto Levels Active)",
            color = Slate300,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )

          Button(
            onClick = onScanForSignal,
            colors = ButtonDefaults.buttonColors(containerColor = Slate800),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
            modifier = Modifier.height(28.dp).testTag("scan_signal_button")
          ) {
            Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "Scan Setup", fontSize = 11.sp)
          }
        }

        // Auto Levels Filter Chips Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(bottom = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          LevelToggleChip("Candle Patterns", showPatterns, Emerald400, onTogglePatterns)
          LevelToggleChip("Fib OTE (0.618-0.786)", showFibonacci, Amber400, onToggleFibonacci)
          LevelToggleChip("Order Blocks (OB)", showOB, Cyan500, onToggleOB)
          LevelToggleChip("Fair Value Gaps (FVG)", showFVG, Emerald400, onToggleFVG)
          LevelToggleChip("BOS / TC (Structure)", showStructure, Blue500, onToggleStructure)
          LevelToggleChip("Sweeps & Liquidity", showLiquidity, Amber400, onToggleLiquidity)
          LevelToggleChip("50% Fib (P/D)", showPDRange, EquilibriumColor, onTogglePDRange)
        }

        CandlestickChart(
          candles = candles,
          orderBlocks = orderBlocks,
          fairValueGaps = fairValueGaps,
          swingPoints = swingPoints,
          structureLines = structureLines,
          asianRangeBox = asianRangeBox,
          liquidityEvents = liquidityEvents,
          pdRange = pdRange,
          fibonacci = fibonacci,
          candlePatterns = candlePatterns,
          symbol = selectedPair,
          showOB = showOB,
          showFVG = showFVG,
          showStructure = showStructure,
          showLiquidity = showLiquidity,
          showPDRange = showPDRange,
          showFibonacci = showFibonacci,
          showPatterns = showPatterns
        )
      }
    }

    // Active Signal Card if generated
    item {
      currentSignal?.let { signal ->
        TradingSignalCard(
          signal = signal,
          onExecute = onExecuteSignal,
          onDismiss = onDismissSignal
        )
      }
    }

    // Active Positions
    item {
      ActivePositionsList(
        positions = activePositions,
        onTakePartials = onTakePartials,
        onMoveBreakeven = onMoveBreakeven,
        onClosePosition = onClosePosition
      )
    }

    item { Spacer(modifier = Modifier.height(16.dp)) }
  }
}

@Composable
private fun LevelToggleChip(
  label: String,
  isActive: Boolean,
  accentColor: Color,
  onToggle: () -> Unit
) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(if (isActive) accentColor.copy(alpha = 0.2f) else Slate900)
      .border(1.dp, if (isActive) accentColor else Slate700, RoundedCornerShape(6.dp))
      .clickable { onToggle() }
      .padding(horizontal = 8.dp, vertical = 3.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      if (isActive) {
        Icon(
          imageVector = Icons.Default.Check,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
      }
      Text(
        text = label,
        color = if (isActive) accentColor else Slate400,
        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
        fontSize = 10.sp
      )
    }
  }
}
